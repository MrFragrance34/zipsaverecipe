﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary4
{
    public class BaseEntity
    {
        private int id;
        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        public override string ToString()
        {
            return $"ID: {Id}";
        }
    }
}
