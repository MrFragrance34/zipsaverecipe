﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary4
{
    public class CategoryList : List<Category>
    {
        public CategoryList() { }
        public CategoryList(IEnumerable<Category> list) : base(list) { }
        public CategoryList(IEnumerable<BaseEntity> list) : base(list.Cast<Category>().ToList()) { }
    }
}
