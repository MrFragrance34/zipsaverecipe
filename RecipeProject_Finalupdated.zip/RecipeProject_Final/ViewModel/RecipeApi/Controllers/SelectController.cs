﻿
using Microsoft.AspNetCore.Mvc;
using ClassLibrary4;
using ViewModel;

namespace RecipeApi.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class SelectController : ControllerBase
    {


        [HttpGet]
        public UserList GetAllUsers()
        {
            UsersDB db = new UsersDB();
            return db.SelectAll();
        }

        [HttpPost]
        public int InsertUser([FromBody] User user)
        {
            UsersDB db = new UsersDB();
            db.Insert(user);
            return db.SaveChanges();
        }

        [HttpPut]
        public int UpdateUser([FromBody] User user)
        {
            UsersDB db = new UsersDB();
            db.Update(user);
            return db.SaveChanges();
        }

        [HttpDelete("{id}")]
        public int DeleteUser(int id)
        {
            UsersDB db = new UsersDB();
            User user = db.SelectAll().Find(x => x.Id == id);

            if (user == null)
                return 0;

            db.Delete(user);
            return db.SaveChanges();
        }



        [HttpGet]
        public AdminList GetAllAdmins()
        {
            AdminsDB db = new AdminsDB();
            return db.SelectAll();
        }

        [HttpPost]
        public int InsertAdmin([FromBody] Admin admin)
        {
            AdminsDB db = new AdminsDB();
            db.Insert(admin);
            return db.SaveChanges();
        }

        [HttpPut]
        public int UpdateAdmin([FromBody] Admin admin)
        {
            AdminsDB db = new AdminsDB();
            db.Update(admin);
            return db.SaveChanges();
        }

        [HttpDelete("{id}")]
        public int DeleteAdmin(int id)
        {
            AdminsDB db = new AdminsDB();
            Admin admin = db.SelectAll().Find(x => x.Id == id);

            if (admin == null)
                return 0;

            db.Delete(admin);
            return db.SaveChanges();
        }




        [HttpGet]
        public CookList GetAllCooks()
        {
            CookDB db = new CookDB();
            return db.SelectAll();
        }

        [HttpPost]
        public int InsertCook([FromBody] Cook cook)
        {
            CookDB db = new CookDB();
            db.Insert(cook);
            return db.SaveChanges();
        }

        [HttpPut]
        public int UpdateCook([FromBody] Cook cook)
        {
            CookDB db = new CookDB();
            db.Update(cook);
            return db.SaveChanges();
        }

        [HttpDelete("{id}")]
        public int DeleteCook(int id)
        {
            CookDB db = new CookDB();
            Cook cook = db.SelectAll().Find(x => x.Id == id);

            if (cook == null)
                return 0;

            db.Delete(cook);
            return db.SaveChanges();
        }




        [HttpGet]
        public CategoryList GetAllCategories()
        {
            CategoryDB db = new CategoryDB();
            return db.SelectAll();
        }

        [HttpPost]
        public int InsertCategory([FromBody] Category category)
        {
            CategoryDB db = new CategoryDB();
            db.Insert(category);
            return db.SaveChanges();
        }

        [HttpPut]
        public int UpdateCategory([FromBody] Category category)
        {
            CategoryDB db = new CategoryDB();
            db.Update(category);
            return db.SaveChanges();
        }

        [HttpDelete("{id}")]
        public int DeleteCategory(int id)
        {
            CategoryDB db = new CategoryDB();
            Category category = db.SelectAll().Find(x => x.Id == id);

            if (category == null)
                return 0;

            db.Delete(category);
            return db.SaveChanges();
        }



        [HttpGet]
        public RecipeList GetAllRecipes()
        {
            RecipesDB db = new RecipesDB();
            return db.SelectAll();
        }

        [HttpPost]
        public int InsertRecipe([FromBody] Recipe recipe)
        {
            RecipesDB db = new RecipesDB();
            db.Insert(recipe);
            return db.SaveChanges();
        }

        [HttpPut]
        public int UpdateRecipe([FromBody] Recipe recipe)
        {
            RecipesDB db = new RecipesDB();
            db.Update(recipe);
            return db.SaveChanges();
        }

        [HttpDelete("{id}")]
        public int DeleteRecipe(int id)
        {
            RecipesDB db = new RecipesDB();
            Recipe recipe = db.SelectAll().Find(x => x.Id == id);

            if (recipe == null)
                return 0;

            db.Delete(recipe);
            return db.SaveChanges();
        }




        [HttpGet]
        public ReviewList GetAllReviews()
        {
            ReviewsDB db = new ReviewsDB();
            return db.SelectAll();
        }

        [HttpPost]
        public int InsertReview([FromBody] Review review)
        {
            ReviewsDB db = new ReviewsDB();
            db.Insert(review);
            return db.SaveChanges();
        }

        [HttpPut]
        public int UpdateReview([FromBody] Review review)
        {
            ReviewsDB db = new ReviewsDB();
            db.Update(review);
            return db.SaveChanges();
        }

        [HttpDelete("{id}")]
        public int DeleteReview(int id)
        {
            ReviewsDB db = new ReviewsDB();
            Review review = db.SelectAll().Find(x => x.Id == id);

            if (review == null)
                return 0;

            db.Delete(review);
            return db.SaveChanges();
        }




        [HttpGet]
        public RecipeCategoryList GetAllRecipeCategories()
        {
            RecipeCategoryDB db = new RecipeCategoryDB();
            return db.SelectAll();
        }

        [HttpPost]
        public int InsertRecipeCategory([FromBody] RecipeCategory recipeCategory)
        {
            RecipeCategoryDB db = new RecipeCategoryDB();
            db.Insert(recipeCategory);
            return db.SaveChanges();
        }

        [HttpPut]
        public int UpdateRecipeCategory([FromBody] RecipeCategory recipeCategory)
        {
            RecipeCategoryDB db = new RecipeCategoryDB();
            db.Update(recipeCategory);
            return db.SaveChanges();
        }

        [HttpDelete("{id}")]
        public int DeleteRecipeCategory(int id)
        {
            RecipeCategoryDB db = new RecipeCategoryDB();
            RecipeCategory recipeCategory =
                db.SelectAll().Find(x => x.Id == id);

            if (recipeCategory == null)
                return 0;

            db.Delete(recipeCategory);
            return db.SaveChanges();
        }
    }
}
