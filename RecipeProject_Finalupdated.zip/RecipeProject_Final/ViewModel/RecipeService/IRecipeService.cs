﻿
using System.Collections.Generic;
using System.Threading.Tasks;
using ClassLibrary4;

namespace RecipeService
{
    public interface IRecipeService
    {
        Task<List<User>> GetAllUsers();
        Task<int> InsertUser(User user);
        Task<int> UpdateUser(User user);
        Task<int> DeleteUser(int id);

        Task<List<Admin>> GetAllAdmins();
        Task<int> InsertAdmin(Admin admin);
        Task<int> UpdateAdmin(Admin admin);
        Task<int> DeleteAdmin(int id);

        Task<List<Cook>> GetAllCooks();
        Task<int> InsertCook(Cook cook);
        Task<int> UpdateCook(Cook cook);
        Task<int> DeleteCook(int id);

        Task<List<Category>> GetAllCategories();
        Task<int> InsertCategory(Category category);
        Task<int> UpdateCategory(Category category);
        Task<int> DeleteCategory(int id);

        Task<List<Recipe>> GetAllRecipes();
        Task<int> InsertRecipe(Recipe recipe);
        Task<int> UpdateRecipe(Recipe recipe);
        Task<int> DeleteRecipe(int id);

        Task<List<Review>> GetAllReviews();
        Task<int> InsertReview(Review review);
        Task<int> UpdateReview(Review review);
        Task<int> DeleteReview(int id);

        Task<List<RecipeCategory>> GetAllRecipeCategories();
        Task<int> InsertRecipeCategory(RecipeCategory recipeCategory);
        Task<int> UpdateRecipeCategory(RecipeCategory recipeCategory);
        Task<int> DeleteRecipeCategory(int id);
    }
}
