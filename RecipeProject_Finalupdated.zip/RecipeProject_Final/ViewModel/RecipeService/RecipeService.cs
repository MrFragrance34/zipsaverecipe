﻿
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using ClassLibrary4;

namespace RecipeService
{
    public class RecipeService : IRecipeService
    {
        private readonly string url;
        private readonly HttpClient client;

        public RecipeService()
        {
            url = "http://localhost:5066/";
            client = new HttpClient();
        }


        public async Task<List<User>> GetAllUsers()
        {
            return await client.GetFromJsonAsync<List<User>>(url + "api/Select/GetAllUsers");
        }

        public async Task<int> InsertUser(User user)
        {
            var response = await client.PostAsJsonAsync(url + "api/Select/InsertUser", user);

            return await response.Content.ReadFromJsonAsync<int>();
        }

        public async Task<int> UpdateUser(User user)
        {
            var response = await client.PutAsJsonAsync(url + "api/Select/UpdateUser", user);

            return await response.Content.ReadFromJsonAsync<int>();
        }

        public async Task<int> DeleteUser(int id)
        {
            var response = await client.DeleteAsync(url + "api/Select/DeleteUser/" + id);

            return await response.Content.ReadFromJsonAsync<int>();
        }


        public async Task<List<Admin>> GetAllAdmins()
        {
            return await client.GetFromJsonAsync<List<Admin>>(url + "api/Select/GetAllAdmins");
        }

        public async Task<int> InsertAdmin(Admin admin)
        {
            var response = await client.PostAsJsonAsync(url + "api/Select/InsertAdmin", admin);

            return await response.Content.ReadFromJsonAsync<int>();
        }

        public async Task<int> UpdateAdmin(Admin admin)
        {
            var response = await client.PutAsJsonAsync(url + "api/Select/UpdateAdmin", admin);

            return await response.Content.ReadFromJsonAsync<int>();
        }

        public async Task<int> DeleteAdmin(int id)
        {
            var response = await client.DeleteAsync(url + "api/Select/DeleteAdmin/" + id);

            return await response.Content.ReadFromJsonAsync<int>();
        }


        public async Task<List<Cook>> GetAllCooks()
        {
            return await client.GetFromJsonAsync<List<Cook>>(url + "api/Select/GetAllCooks");
        }

        public async Task<int> InsertCook(Cook cook)
        {
            var response = await client.PostAsJsonAsync(url + "api/Select/InsertCook", cook);

            return await response.Content.ReadFromJsonAsync<int>();
        }

        public async Task<int> UpdateCook(Cook cook)
        {
            var response = await client.PutAsJsonAsync(url + "api/Select/UpdateCook", cook);

            return await response.Content.ReadFromJsonAsync<int>();
        }

        public async Task<int> DeleteCook(int id)
        {
            var response = await client.DeleteAsync(url + "api/Select/DeleteCook/" + id);

            return await response.Content.ReadFromJsonAsync<int>();
        }


        public async Task<List<Category>> GetAllCategories()
        {
            return await client.GetFromJsonAsync<List<Category>>(url + "api/Select/GetAllCategories");
        }

        public async Task<int> InsertCategory(Category category)
        {
            var response = await client.PostAsJsonAsync(url + "api/Select/InsertCategory", category);

            return await response.Content.ReadFromJsonAsync<int>();
        }

        public async Task<int> UpdateCategory(Category category)
        {
            var response = await client.PutAsJsonAsync(url + "api/Select/UpdateCategory", category);

            return await response.Content.ReadFromJsonAsync<int>();
        }

        public async Task<int> DeleteCategory(int id)
        {
            var response = await client.DeleteAsync(url + "api/Select/DeleteCategory/" + id);

            return await response.Content.ReadFromJsonAsync<int>();
        }


        public async Task<List<Recipe>> GetAllRecipes()
        {
            return await client.GetFromJsonAsync<List<Recipe>>(url + "api/Select/GetAllRecipes");
        }

        public async Task<int> InsertRecipe(Recipe recipe)
        {
            var response = await client.PostAsJsonAsync(url + "api/Select/InsertRecipe", recipe);

            return await response.Content.ReadFromJsonAsync<int>();
        }

        public async Task<int> UpdateRecipe(Recipe recipe)
        {
            var response = await client.PutAsJsonAsync(url + "api/Select/UpdateRecipe", recipe);

            return await response.Content.ReadFromJsonAsync<int>();
        }

        public async Task<int> DeleteRecipe(int id)
        {
            var response = await client.DeleteAsync(url + "api/Select/DeleteRecipe/" + id);

            return await response.Content.ReadFromJsonAsync<int>();
        }


        public async Task<List<Review>> GetAllReviews()
        {
            return await client.GetFromJsonAsync<List<Review>>(url + "api/Select/GetAllReviews");
        }

        public async Task<int> InsertReview(Review review)
        {
            var response = await client.PostAsJsonAsync(url + "api/Select/InsertReview", review);

            return await response.Content.ReadFromJsonAsync<int>();
        }

        public async Task<int> UpdateReview(Review review)
        {
            var response = await client.PutAsJsonAsync(url + "api/Select/UpdateReview", review);

            return await response.Content.ReadFromJsonAsync<int>();
        }

        public async Task<int> DeleteReview(int id)
        {
            var response = await client.DeleteAsync(url + "api/Select/DeleteReview/" + id);

            return await response.Content.ReadFromJsonAsync<int>();
        }



        public async Task<List<RecipeCategory>> GetAllRecipeCategories()
        {
            return await client.GetFromJsonAsync<List<RecipeCategory>>(url + "api/Select/GetAllRecipeCategories");
        }

        public async Task<int> InsertRecipeCategory(RecipeCategory recipeCategory)
        {
            var response = await client.PostAsJsonAsync(url + "api/Select/InsertRecipeCategory", recipeCategory);

            return await response.Content.ReadFromJsonAsync<int>();
        }

        public async Task<int> UpdateRecipeCategory(RecipeCategory recipeCategory)
        {
            var response = await client.PutAsJsonAsync(url + "api/Select/UpdateRecipeCategory", recipeCategory);

            return await response.Content.ReadFromJsonAsync<int>();
        }

        public async Task<int> DeleteRecipeCategory(int id)
        {
            var response = await client.DeleteAsync(url + "api/Select/DeleteRecipeCategory/" + id);

            return await response.Content.ReadFromJsonAsync<int>();
        }
    }
}
