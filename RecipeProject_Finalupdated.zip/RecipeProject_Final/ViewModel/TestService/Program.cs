﻿
using System;
using System.Threading.Tasks;
using RecipeService;

class Program
{
    static async Task Main(string[] args)
    {
        global::RecipeService.RecipeService service =
            new global::RecipeService.RecipeService();

        // Find the user
        var users = await service.GetAllUsers();

        var user = users.Find(u =>
            u.Email == "testservice@example.com");

        if (user == null)
        {
            Console.WriteLine("User not found!");
            return;
        }

        Console.WriteLine("User before deletion:");
        Console.WriteLine(user);

        // Delete user
        int result = await service.DeleteUser(user.Id);

        Console.WriteLine($"\nDelete result: {result}");

        // Verify deletion
        var usersAfter = await service.GetAllUsers();

        var deletedUser = usersAfter.Find(u =>
            u.Email == "testservice@example.com");

        Console.WriteLine(
            deletedUser == null
                ? "\nUser successfully deleted!"
                : "\nUser still exists!");
    }
}
